const express = require("express")
const app = express()
const port = 4000
const bodyParser = require('body-parser');
const session = require('express-session');
const fs = require('fs');
const db = require('./db/db')
const allroutes = require('./routes/routes')
const FetchingRoute = require('./routes/fetching')



//////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

app.set('view engine', 'hbs')
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

////////////////////sessions init\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
app.use(session({
	key: 'session_cookie_name',
	secret: 'key',
	store: db.sessionStore,
	resave: false,
	saveUninitialized: false,
}));

db.sessionStore.onReady().then(() => {
	// MySQL session store ready for use.
	console.log('MySQLStore ready');
}).catch(error => {
	// Something went wrong.
	console.error(error);
});

////////////////////////////fichier des document js et css et autre\\\\\\\\\\\\\\\\\\\\\\\\\
const path = require("path");
const publicDir = path.join(__dirname, 'public');  
app.use(express.static(publicDir));
app.use('/uploads', express.static('uploads'));

////////////////////////pages routes\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

app.use(allroutes, FetchingRoute);

///////////////////////////////////fetching\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\







/////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
app.listen(port, () => console.log(`Example app listening on port ${port}!`));
 
app.get('/print/:path', async (req, res) => {
       const path = req.params.path;
       console.log(path);
         try {
        
                
                    // Read the file content from the server's filesystem
                const docContent = fs.readFileSync(path, 'utf-8');
               
           
        } catch (error) {
            console.error(error);
            throw error;
        }
  
})