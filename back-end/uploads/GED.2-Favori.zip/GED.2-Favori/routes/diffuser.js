const express = require("express");
const route = express.Router();
const db = require('../db/db');
let doc;
route.post('/getnom', async (req, res) => doc=req.body.nom_doc)

route.post('/', async function (req, res) {
    console.log(req.body);
const nom_doc= doc;
    const target =  req.body.target ;
    console.log(nom_doc,target);
    // Ensure targets is an array
    if (!Array.isArray(target)) {
        res.render('./Mydocuments', { message: 'Please select a target' });
    }else{
    // Iterate over targets and perform necessary actions
    for (const targe of target) {
        await db.dbIdReciever(targe, nom_doc);
    }
    // Respond with success
    res.status(200).json({ success: true });}
});
module.exports = route
route.get('/documents/:nom_doc', async function (req, res) {
    const nom_doc = req.params.nom_doc;
    res.redirect('/download/${nom_doc}' );
})
module.exports = route