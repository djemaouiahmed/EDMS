const express = require("express");
const route = express.Router();
const post_docRoute = require('./post_doc')
const downloadRoute = require('./download')
const HMPAGE = require('./home_page')
const login=require('../controller/login')
const adminFonctionalities = require('../controller/adminFonctionalities')
const authenticate = require('../middleware/authenticate')
const diffuser = require('./diffuser')
const SRHroute = require('./search')





route.get('/', (req, res) => res.render('login'))
route.get('/logout', (req, res) => { req.session.destroy();res.redirect('/');})
route.use('/download',downloadRoute)
route.get('/Mydocuments', (req, res) => res.render('MyDocuments'))
route.use("/post_doc", post_docRoute);
route.use('/home_page',HMPAGE)
route.use('/diffuser',diffuser)

//route.use('/login',loginRoute)
///////////////////////////////////////////////////////////////////////////////
route.post('/login',login.login);
route.post('/register', login.register);
route.use('/admin',authenticate.authenticate ,(req, res) => res.render('admin'));

route.get('/verify',(req,res)=>{if(req.session.role=="responsable"){res.render('VerifyDoc')}})

route.post('/admin/del', adminFonctionalities.deleteUser);
route.use('/search',SRHroute);


/////////////////////////////////////////////////////////////////////////////
module.exports = route