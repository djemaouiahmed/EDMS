
const express = require("express")
const mysql = require('mysql2')
const route = express.Router()
const session=require('../application')
const db = require('../db/db')








////////////////////uploads files//////////////////////////
const multer  = require('multer');
const { error, debug } = require("console");
const { dbUploadDocument } = require("../db/db")
const filsaveengine = multer.diskStorage({
    destination:  function (req, file, cb) {
        var t=req.body.type;
      cb(null, './uploads/'+t)
    },
    filename: function (req, file, cb) {
        if(req.body.upload_file==""){
      cb(null,file.originalname)}
        else{
            cb(null,req.body.upload_file)
        }
    }
}) 
const upload = multer({ storage: filsaveengine })


route.post('/', upload.single('file'), async function (req, res) {
    if(!req.file){
        res.render('post_doc', { message: 'Please select a file to upload' });
    }else{

       
        
   var type=req.body.type;
   var filename;
   if(req.body.upload_file==""){
    filename=req.file.originalname 
   }else{
    filename=req.body.upload_file;
   }
   var commentaire=req.body.commentaire;
    
    var id_user = req.session.id_user;
  var mots = req.body.mot_cle;
    var path = req.file.destination; // Access file type using req.file.mimetype
    var datetime = new Date();
   
    var mot=mots.split(";");
  
    for(var i=0;i<5;i++){if(mot[i]==undefined){mot[i]="";}}
   
        
      // Format the date to MySQL datetime format
    const formattedDateTime = datetime.toISOString().slice(0, 19).replace('T', ' ')
       db.dbUploadDocument(res,id_user, filename, type, path, mot, formattedDateTime,commentaire);
        
       
       console.log(req.file, req.body);
          const target=req.body.target;
          if(target!=null){
             for(var i=0;i<target.length;i++){
            db.dbIdReciever(target[i],filename);}}
        
    }});















////////////////////////////////////////



// Optionally use onReady() to get a promise that resolves when store is ready.


route.get('/',async (req, res)=>{ 
 
    res.render('./post_doc');
  


})

module.exports = route
