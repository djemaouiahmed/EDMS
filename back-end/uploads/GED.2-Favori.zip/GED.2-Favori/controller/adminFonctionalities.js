

const express = require('express')
const jwt = require('jsonwebtoken');
const path = require('path')
const db = require('../db/db');
const nodemailer = require('nodemailer');
const {session}=require('../application')
const route_admin = express.Router();



  
  async function deleteUser (req, res)  {


    const idd = req.body.e
  db.dbDelUserById(idd)
    }
  



    async function acceptUser (req, res) {
      const urlll= req.protocol + '://' + req.get('host');

 
      let EMAIL_SECRET = 'your_secret_key';

        try {
          
          const transporter = nodemailer.createTransport({
            service: "Gmail",
            auth: {
            
                user: "djalal.aymn@gmail.com", 
                pass: "pjqq infd pgso jfqx"
            }
          
          });
          
          const id = req.body.e; 
       
        const upload = req.body.upload;
        const print = req.body.print;
        const download = req.body.download;
        console.log(req.body);
      const results= await db.dbGetUserEmailById(id);
         
     
          if (!results.length) {
            return res.status(404).send('User not found');
          }
      
          const userEmail = results[0].email;
      
         
          const emailToken = jwt.sign({ user: { id } }, EMAIL_SECRET);
      
          console.log(emailToken)
          const url = `${urlll}/confirmation/${emailToken}`;
      
          await transporter.sendMail({
            to: userEmail,
            subject: 'Confirm Email',
            html: `Please click this email to confirm your email: <a href="${url}">${url}</a>`,
          });
          

              res.send('Confirmation email sent successfully'); 

            } catch (err) {
              console.error(err);
             
            }
      
    }

    async function confirmationToken (token,Email) {

        console.log(Email);
      
    
        const decoded = jwt.verify(token, Email);
        const userId = decoded.user.id;
        
       await db.dbVerifyUserByID(userId)
      
        console.log('User verified successfully');
      
    
      }
    
    async function getUsers (req, res) {
    const results = await db.dbGetUnverifiedUsers();
      res.json(results);
      
      }
    


  module.exports = {getUsers : getUsers,deleteUser : deleteUser,acceptUser : acceptUser ,confirmationToken : confirmationToken}
