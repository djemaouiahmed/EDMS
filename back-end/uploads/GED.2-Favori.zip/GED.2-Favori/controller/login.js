
const bcrypt = require('bcrypt');

const mysql = require('mysql2/promise'); 
const { dbFindUserByEmail, dbInsertUser } = require('../db/db');




async function login (req, res) {

    const login = req.body
  
   
  
  
    
    if (login.email == null || login.password == null) {
      return res.status(422)
    }
   

    const results = await dbFindUserByEmail(login.email);
   
    const responseBody = {
    results : results
    }
  
       if (results.length == 0) {console.log("not found")
     
  res.status(422).json(responseBody)
      }


        else{ 
       const valid =  await bcrypt.compare(login.password, results[0].password);
       if( valid ){req.session.id_user = results[0].id_user;
        req.session.nom =results[0].nom;
        req.session.prenom =results[0].prenom;
        req.session.role=results[0].roles;
       
        
        console.log(req.session.id_user);
         req.session.isAuth=true;
         

        res.redirect("/home_page");
      }
  
  
       else{
        res.render('login',{message:"invalid password"})
       }
        }
       
       
      };



      async function register (req, res) {

        const register = req.body


        if (register.fname == null || register.lname == null || register.email == null || register.password == null) {
          console.log(register);
          return res.status(422).send({ error: 'You must provide pass and username' });
        }
        let hashedPassword = await bcrypt.hash(register.password, 10);
 dbInsertUser(register.fname,register.lname,register.email,hashedPassword);
     res.redirect('/');

      }


      module.exports = {login :login ,register :register}