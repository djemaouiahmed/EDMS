const mysql = require('mysql2/promise');
const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'ged2024',
    database: 'ged',
      
});
const sessionStore = new MySQLStore({
    createDatabaseTable: true, // This will create the sessions table if it doesn't exist
    schema: {
        tableName: 'sessions', // Customize the name of the sessions table if needed
    },
    expiration: 86400000, // Session expiration time in milliseconds (optional)
     host: 'localhost',
    user: 'root',
    password: 'ged2024',
    database: 'ged',
});















////////////////////////querys\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

async function dbCountDocAdded(id_user) {
    try {
        const con = await pool.getConnection();
        const [result] = await con.query('SELECT COUNT(*) AS num FROM table_document WHERE id_user_source = ? AND isVerfied = 1', [id_user]);
        con.release();
        return result[0].num;
    } catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }
}
async function dbListDocumentsNV() {
    try {
        const con = await pool.getConnection();
        const sql = `SELECT user.nom, user.prenom, id_user_source, date_time, nom_doc,commentaire 
                     FROM table_document
                     JOIN user ON   table_document.id_user_source = user.id_user WHERE table_document.isVerfied = 0;`;
        const [result] = await con.query(sql);
        con.release();
        return result;
    } catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }
}

async function dbListDocumentsReceved(id_user) {
    try {
        const con = await pool.getConnection();
        const sql = `SELECT nom, prenom, id_user_fk, id_user_source, date_time, nom_doc,commentaire,path
                     FROM (
                         SELECT id_user_fk, id_user_source, date_time, table_document.nom_doc ,commentaire ,path
                         FROM table_previlege 
                         JOIN table_document ON table_document.nom_doc = table_previlege.nom_doc 
                         WHERE table_previlege.id_user_fk = ? AND table_document.isVerfied = 1
                     ) AS subquery 
                     JOIN user ON user.id_user = subquery.id_user_source;`;
        const [result] = await con.query(sql, [id_user]);
        con.release();
        return result;
    } catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }
}
async function dbMyDocuments(id_user) {
    try {
        const con = await pool.getConnection();
        const sql = 'SELECT * FROM table_document WHERE id_user_source = ?;';
        const [result] = await con.query(sql, [id_user]);
        con.release();
        return result;
    }catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }}
async function dbAllDocs() {
    try {
        const con = await pool.getConnection();
        const sql = 'SELECT * FROM table_document ;';
        const [result] = await con.query(sql);
       
        con.release();
        return result;
    }catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }}

async function dbDownloadDocument(id_user, documentId) {
    try {
        const con = await pool.getConnection();
        const sql = 'SELECT * FROM ged.table_previlege JOIN table_document ON table_document.nom_doc = table_previlege.nom_doc WHERE table_previlege.id_user_fk = ? AND table_document.nom_doc = ? AND table_document.isVerfied = 1;';
        const [result] = await con.query(sql, [id_user, documentId]);
        if (result.length > 0) {
        con.release();
        return result;
        }else{
            const sql2 = 'SELECT * FROM table_document WHERE id_user_source = ? AND isVerfied = 1;';
            const [result2] = await con.query(sql2, [id_user]);
            con.release();
            return result2;
        }
        
    } catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }
}
async function dbUploadDocument(res,id_user, filename, type, path, mot, formattedDateTime,commentaire) {
    try {
        const con = await pool.getConnection();
   var query = `INSERT INTO table_document (nom_doc, type, path, date_time,mot_1,mot_2,mot_3,mot_4,mot_5,id_user_source,commentaire) VALUES ('${filename}', '${type}', '${path}', '${formattedDateTime}','${mot[0]}','${mot[1]}','${mot[2]}','${mot[3]}','${mot[4]}','${id_user}','${commentaire}') `;
        await con.execute(query);
        con.release();
         res.render('post_doc', { message: 'File uploaded successfully' });
       
    } catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }
}

async function dbIdReciever(target, filename) {
    
    try {
        const con = await pool.getConnection();
        var query = `SELECT * FROM table_previlege WHERE id_user_fk = '${target}' AND nom_doc = '${filename}'`;
        const [result] = await con.query(query);
        if (result.length > 0) {
            con.release();
        }else{
 var query2=`INSERT INTO table_previlege(id_user_fk,nom_doc)VALUE('${target}','${filename}')`
        await con.execute(query2);
        con.release();


        }
         
       
    } catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }
}

async function dbListUsers(id_user) {
    try {
        const con = await pool.getConnection();
      var sql =  'SELECT * FROM user WHERE not id_user = ? and verified = 1';
        const [result] = await con.query(sql, [id_user]);
        con.release();
        return result;
    } catch (error) {
        console.error( error);
    }
}
async function dbInsertUser (fname,lname,Email,password) {
    const con = await pool.getConnection();
    
    await con.execute("insert into user (prenom,nom,email,password) values(?,?,?,?)",[fname,lname,Email,password])
con.release();

 }




 async function dbFindUserByEmail(email) {
     
    const con = await pool.getConnection();

   
    
   
  const [results] = await con.query("select * from user where email = ?",[email]);
  con.release(); 
  
    return results
 }

 async function dbGetUserEmailById(id ) {
    const connection = await pool.getConnection();
    const [results] = await connection.query('SELECT email FROM user WHERE id_user = ?', [id]);
    return results
 }



 async function dbGetUnverifiedUsers() {
    const con = await pool.getConnection();
    var sql = "select id_user ,email,prenom ,nom from user where verified = 0";   
   const [results] = await con.query(sql);
   con.release();
   return results

 }

 async function dbDelUserById(id) {
   
    const con = await pool.getConnection();
    const sql = "DELETE FROM user WHERE id_user = ?";
  await con.execute(sql, [id]);
  con.release();
 }

async function dbVerifyUserByID (id) {
    const con = await pool.getConnection();
   await con.execute( 'UPDATE user SET verified = ? WHERE id_user = ?',
    [1, id])
    con.release();
  } 


async function dbListFavori(id_user) {
    try {
        const con = await pool.getConnection();
        const sql = `SELECT nom, prenom, id_user_fk, id_user_source, date_time, nom_doc, commentaire
                  FROM (
                        SELECT id_user_fk, id_user_source, date_time, table_document.nom_doc, commentaire
                        FROM table_previlege
                        JOIN table_document ON table_document.nom_doc = table_previlege.nom_doc
                        WHERE table_previlege.id_user_fk = ?
                          ) AS subquery 
                        JOIN user ON user.id_user = subquery.id_user_source
                        WHERE EXISTS (
                         SELECT 1
                        FROM table_favori
                           WHERE nom_document = subquery.nom_doc );`;
                     
        const [result] = await con.query(sql, [id_user]);
        con.release();
        return result;
    } catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }
}


async function dbAddFavori(id, filename) {
     const con = await pool.getConnection();
     const sql = `SELECT COUNT(*) AS num  FROM table_favori WHERE id = ? AND nom_document = ?;`;
    const [result] = await con.query(sql, [id, filename]);
    if (result[0].num > 0) {
        con.release();
        
        console.log('Document already favorited');
        const slq2 = `DELETE FROM table_favori WHERE id = ? AND nom_document = ?;`;
        await con.execute(slq2, [id, filename]);
        return false;
    }else{

    await con.execute("insert into table_favori (id,nom_document) values(?,?)",[id,filename])
con.release();
    return true;
}}

async function dbCheckFavori(id, filename) {
    const con = await pool.getConnection();
    const sql = `SELECT COUNT(*) AS num  FROM table_favori WHERE id = ? AND nom_document = ?;`;
    const [result] = await con.query(sql, [id, filename]);
    con.release();
    return result[0].num > 0;
}

async function dbVerifyDocument(id_user, documentId) {
    try {
        const con = await pool.getConnection();
        const sql = 'UPDATE table_document SET isVerfied =1 WHERE id_user_source = ? AND nom_doc = ?;';
        await con.execute(sql, [id_user, documentId]);
        con.release();
    } catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }
}
async function dbSearch(name, type, keyword) {
    const con = await pool.getConnection();
    try {
          let query = `SELECT * FROM table_document WHERE 1`;

    // Add conditions based on the provided search criteria
    if (name) {
        query += ` AND nom_doc LIKE '${name}%'`;
    }
    if (type) {
        query += ` AND type LIKE '%${type}%'`;
    }
    if (keyword) {
        query += ` AND (mot_1 LIKE '%${keyword}%' OR mot_2 LIKE '%${keyword}%' OR mot_3 LIKE '%${keyword}%' OR mot_4 LIKE '%${keyword}%' OR mot_5 LIKE '%${keyword}%')`;
    }
        const [result] = await con.query(query);
        con.release();
        return result;
    } catch (error) {
        console.error( error);
        throw error; // Rethrow the error for the calling function to handle
    }
}










module.exports = { dbCountDocAdded, dbListDocumentsReceved,dbMyDocuments,dbSearch
     ,dbDownloadDocument , dbUploadDocument , dbListUsers,dbIdReciever,sessionStore,dbInsertUser,dbFindUserByEmail,dbGetUserEmailById,dbGetUnverifiedUsers,dbDelUserById,dbVerifyUserByID
,dbListFavori,dbAddFavori,dbCheckFavori,dbVerifyDocument,dbListDocumentsNV,dbAllDocs
};
