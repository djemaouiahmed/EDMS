//pdf-viewer
 async function loadPDF(path) {
        const pdfViewer = document.getElementById('pdfViewer');
        pdfViewer.innerHTML = ''; // Clear any existing canvas elements

        const url = path; // Replace with your PDF URL
        pdfjsLib.getDocument(url).promise.then(function (pdfDoc) {
            for (let pageNum = 1; pageNum <= pdfDoc.numPages; pageNum++) {
                pdfDoc.getPage(pageNum).then(function (page) {
                    const canvas = document.createElement('canvas');
                    pdfViewer.appendChild(canvas);
                    const context = canvas.getContext('2d');
                    const viewport = page.getViewport({ scale: 1.5 });
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;
                    page.render({
                        canvasContext: context,
                        viewport: viewport
                    });
                });
            }
        });
    }

//favori-functions

            async function toggleFavorite(nom_doc, icon) {
                try {
                    const response = await fetch(`/addfavori/${nom_doc}`);
                    console.log('Server response:', response);
                    if (response.ok) {
                        const responseData = await response.json();

                        console.log('Server response:', responseData);
                        if (responseData.isFavorite) {
                            icon.style.color = 'yellow';
                        } else {
                            icon.style.color = 'black';
                        }
                    } else {
                        throw new Error('Failed to add favori:', response.statusText);
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            }
            async function CheckFavori(nom_doc, icon) {
                try {
                    const response = await fetch(`/Checkfavori/${nom_doc}`);


                    const responseData = await response.json();
                    if (responseData.isFavorite) {
                        icon.style.color = 'yellow';
                    } else {
                        icon.style.color = 'black';
                    }

                } catch (error) {

                }
            }





            